import math


def distance(p1, p2):
    """Calculate the Euclidean distance between two points."""
    return math.sqrt((p1[0] - p2[0]) ** 2 + (p1[1] - p2[1]) ** 2)


def closest_pair(points):
    """Find the closest pair of points using divide and conquer."""
    n = len(points)

    # Base case: if there are only two points, return them
    if n == 2:
        return points[0], points[1], distance(points[0], points[1])

    # Base case: if there is only one point, return None
    if n == 1:
        return None, None, float("inf")

    # Sort the points based on their x-coordinate
    points_sorted_x = sorted(points, key=lambda p: p[0])

    # Divide the points into two subsets
    mid = n // 2
    left_points = points_sorted_x[:mid]
    right_points = points_sorted_x[mid:]

    # Recursively find the closest pair in each subset
    left_pair1, left_pair2, left_distance = closest_pair(left_points)
    right_pair1, right_pair2, right_distance = closest_pair(right_points)

    # Determine the smaller distance between the two subsets
    min_distance = min(left_distance, right_distance)

    # Find the points within the minimum distance around the middle line
    mid_line = (left_points[-1][0] + right_points[0][0]) / 2
    points_within_distance = [p for p in points_sorted_x if abs(p[0] - mid_line) < min_distance]

    # Check for closer pairs in the middle area
    closest_pair = None
    for i in range(len(points_within_distance)):
        for j in range(i + 1, min(i + 7, len(points_within_distance))):
            dist = distance(points_within_distance[i], points_within_distance[j])
            if dist < min_distance:
                min_distance = dist
                closest_pair = (points_within_distance[i], points_within_distance[j])

    # Determine the final closest pair
    if closest_pair:
        return closest_pair[0], closest_pair[1], min_distance
    elif left_distance < right_distance:
        return left_pair1, left_pair2, left_distance
    else:
        return right_pair1, right_pair2, right_distance
    
    # Example usage
points = [(2, 3), (12, 30), (40, 50), (5, 1), (12, 10), (3, 4)]
p1, p2, min_distance = closest_pair(points)

print("Closest pair: ", p1, p2)
print("Distance: ", min_distance)

